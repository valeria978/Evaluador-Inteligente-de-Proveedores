import { describe, it, expect } from "vitest";
import { calcularPuntaje, clasificar } from "./evaluador";

describe("puntaje", () => {
  it("aplica pesos 35/20/20/15/10", () => {
    expect(calcularPuntaje({ calidad: 100, documentacion: 0, transporte: 0, puntualidad: 0, servicio: 0 })).toBe(35);
    expect(calcularPuntaje({ calidad: 0, documentacion: 100, transporte: 100, puntualidad: 100, servicio: 100 })).toBe(65);
  });
  it("clasifica A/B/C/D", () => {
    expect(clasificar(90)).toBe("A");
    expect(clasificar(89.9)).toBe("B");
    expect(clasificar(75)).toBe("B");
    expect(clasificar(60)).toBe("C");
    expect(clasificar(59.9)).toBe("D");
  });
  it("rechaza si falla inocuidad", () => {
    expect(clasificar(100, false)).toBe("Rechazado");
  });
});
