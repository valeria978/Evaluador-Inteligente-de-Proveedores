import { useEffect, useState, useCallback } from "react";

export type Documento = { tipo: "Registro sanitario" | "Ficha técnica" | "Certificado BPM"; vence: string };
export type Proveedor = { id: string; nombre: string; insumo: string; contacto: string; documentos: Documento[] };
export type CriterioKey = "calidad" | "documentacion" | "transporte" | "puntualidad" | "servicio";
export type Evaluacion = {
  id: string;
  proveedorId: string;
  fecha: string;
  lote: string;
  notas: Record<CriterioKey, number>; // 0-100
  inocuidad: Record<string, boolean>; // true = cumple
  observaciones: string;
};

export const CRITERIOS: { key: CriterioKey; label: string; peso: number }[] = [
  { key: "calidad", label: "Calidad del producto", peso: 0.35 },
  { key: "documentacion", label: "Documentación", peso: 0.2 },
  { key: "transporte", label: "Transporte (temperatura y empaque)", peso: 0.2 },
  { key: "puntualidad", label: "Puntualidad y cantidad entregada", peso: 0.15 },
  { key: "servicio", label: "Servicio y reclamos", peso: 0.1 },
];

export const INOCUIDAD = [
  "Temperatura de recepción dentro del rango",
  "Empaque íntegro y sin contaminación",
  "Sin presencia de plagas, olores o cuerpos extraños",
  "Producto dentro de su fecha de vida útil",
];

export const INSUMOS = ["Harina", "Huevos", "Leche", "Mantequilla", "Azúcar", "Levadura", "Otro"];

export function calcularPuntaje(notas: Record<CriterioKey, number>): number {
  const total = CRITERIOS.reduce((s, c) => s + (notas[c.key] ?? 0) * c.peso, 0);
  return Math.round(total * 10) / 10;
}

export type Clase = "A" | "B" | "C" | "D" | "Rechazado";
export function clasificar(puntaje: number, inocuidadOk = true): Clase {
  if (!inocuidadOk) return "Rechazado";
  if (puntaje >= 90) return "A";
  if (puntaje >= 75) return "B";
  if (puntaje >= 60) return "C";
  return "D";
}

export function inocuidadOk(ev: Pick<Evaluacion, "inocuidad">) {
  return INOCUIDAD.every((k) => ev.inocuidad[k] !== false);
}

export function resultado(ev: Evaluacion) {
  const p = calcularPuntaje(ev.notas);
  const ok = inocuidadOk(ev);
  return { puntaje: ok ? p : 0, puntajeBruto: p, clase: clasificar(p, ok), rechazado: !ok };
}

const SUGERENCIAS: Record<CriterioKey, string> = {
  calidad: "Solicitar análisis de laboratorio del lote, reforzar inspección organoléptica y exigir plan de mejora de calidad.",
  documentacion: "Requerir actualización de registro sanitario, ficha técnica y certificado BPM antes de la próxima entrega.",
  transporte: "Exigir registro de temperatura del vehículo, mejorar embalaje y verificar limpieza del transporte.",
  puntualidad: "Acordar ventanas de entrega fijas y penalización por faltantes; evaluar proveedor alterno de respaldo.",
  servicio: "Programar reunión de seguimiento, definir tiempos de respuesta a reclamos y canal de comunicación directo.",
};

export function criterioMasBajo(notas: Record<CriterioKey, number>) {
  return CRITERIOS.reduce((min, c) => (notas[c.key] < notas[min.key] ? c : min), CRITERIOS[0]);
}

export function sugerencia(ev: Evaluacion) {
  if (!inocuidadOk(ev))
    return "Lote rechazado por inocuidad: devolver el lote, levantar no conformidad y suspender compras hasta auditoría al proveedor.";
  const c = criterioMasBajo(ev.notas);
  return `${c.label} (${ev.notas[c.key]}): ${SUGERENCIAS[c.key]}`;
}

export function diasParaVencer(fecha: string) {
  const d = new Date(fecha + "T00:00:00").getTime() - new Date().setHours(0, 0, 0, 0);
  return Math.round(d / 86400000);
}
export function estadoDoc(fecha: string): "vencido" | "proximo" | "vigente" {
  const d = diasParaVencer(fecha);
  return d < 0 ? "vencido" : d <= 30 ? "proximo" : "vigente";
}

export const claseStyle: Record<Clase, string> = {
  A: "bg-grade-a text-grade-fg",
  B: "bg-grade-b text-grade-fg",
  C: "bg-grade-c text-foreground",
  D: "bg-grade-d text-grade-fg",
  Rechazado: "bg-destructive text-grade-fg",
};

// ---------- datos de ejemplo + almacenamiento local ----------
const hoy = new Date();
const iso = (offsetDays: number) => {
  const d = new Date(hoy);
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().slice(0, 10);
};
const docs = (a: number, b: number, c: number): Documento[] => [
  { tipo: "Registro sanitario", vence: iso(a) },
  { tipo: "Ficha técnica", vence: iso(b) },
  { tipo: "Certificado BPM", vence: iso(c) },
];
const SEED_P: Proveedor[] = [
  { id: "p1", nombre: "Molinos del Valle", insumo: "Harina", contacto: "ventas@molinosvalle.co", documentos: docs(200, 120, 15) },
  { id: "p2", nombre: "Granja La Esperanza", insumo: "Huevos", contacto: "310 555 1234", documentos: docs(-5, 90, 300) },
  { id: "p3", nombre: "Lácteos San Pedro", insumo: "Leche", contacto: "pedidos@sanpedro.co", documentos: docs(365, 25, 180) },
  { id: "p4", nombre: "Harinera Andina", insumo: "Harina", contacto: "320 444 9876", documentos: docs(150, 200, 250) },
];
const n = (calidad: number, documentacion: number, transporte: number, puntualidad: number, servicio: number) => ({ calidad, documentacion, transporte, puntualidad, servicio });
const ok = Object.fromEntries(INOCUIDAD.map((k) => [k, true]));
const SEED_E: Evaluacion[] = [
  ["p1", -80, n(92, 90, 88, 95, 90)], ["p1", -50, n(95, 92, 90, 90, 95)], ["p1", -20, n(96, 95, 92, 95, 92)],
  ["p2", -75, n(80, 60, 70, 85, 80)], ["p2", -45, n(78, 55, 72, 80, 75)], ["p2", -10, n(82, 50, 75, 85, 80)],
  ["p3", -70, n(70, 80, 55, 60, 70)], ["p3", -40, n(75, 82, 60, 65, 70)], ["p3", -12, n(72, 85, 65, 70, 75)],
  ["p4", -60, n(60, 70, 65, 50, 55)], ["p4", -30, n(55, 65, 60, 45, 50)],
].map(([pid, d, notas], i) => ({
  id: "e" + i, proveedorId: pid as string, fecha: iso(d as number), lote: "L-" + (1000 + i),
  notas: notas as Record<CriterioKey, number>, inocuidad: { ...ok }, observaciones: "",
}));
SEED_E.push({ id: "e99", proveedorId: "p2", fecha: iso(-3), lote: "L-1099", notas: n(70, 60, 40, 80, 70),
  inocuidad: { ...ok, [INOCUIDAD[0]]: false }, observaciones: "Huevos recibidos a 14 °C" });

const KEY = "evaluador-proveedores-v1";
type Data = { proveedores: Proveedor[]; evaluaciones: Evaluacion[] };
let cache: Data = { proveedores: SEED_P, evaluaciones: SEED_E };
const subs = new Set<() => void>();
let loaded = false;

export function useStore() {
  const [data, setData] = useState<Data>(cache);
  useEffect(() => {
    if (!loaded) {
      loaded = true;
      try { const raw = localStorage.getItem(KEY); if (raw) cache = JSON.parse(raw); } catch {}
    }
    setData(cache);
    const fn = () => setData(cache);
    subs.add(fn);
    return () => { subs.delete(fn); };
  }, []);
  const update = useCallback((f: (d: Data) => Data) => {
    cache = f(cache);
    localStorage.setItem(KEY, JSON.stringify(cache));
    subs.forEach((s) => s());
  }, []);
  return { ...data, update };
}

export const uid = () => Math.random().toString(36).slice(2, 10);
