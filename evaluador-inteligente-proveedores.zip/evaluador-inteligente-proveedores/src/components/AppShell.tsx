import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { LayoutDashboard, Truck, ClipboardCheck, FileText, Wheat } from "lucide-react";
import { claseStyle, type Clase } from "@/lib/evaluador";

const NAV = [
  { to: "/", label: "Panel", icon: LayoutDashboard },
  { to: "/proveedores", label: "Proveedores", icon: Truck },
  { to: "/evaluar", label: "Evaluar lote", icon: ClipboardCheck },
  { to: "/reporte", label: "Reporte", icon: FileText },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <header className="bg-warm text-primary-foreground no-print">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-4">
          <Wheat className="h-7 w-7" />
          <div className="flex-1">
            <h1 className="text-lg font-semibold leading-tight md:text-2xl">Evaluador Inteligente de Proveedores</h1>
            <p className="text-xs opacity-90">Control de insumos de panadería</p>
          </div>
          <nav className="hidden gap-1 md:flex">
            {NAV.map((n) => (
              <Link key={n.to} to={n.to} activeOptions={{ exact: true }}
                className="rounded-full px-4 py-2 text-sm font-semibold hover:bg-primary-foreground/15"
                activeProps={{ className: "bg-primary-foreground/25" }}>{n.label}</Link>
            ))}
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6">{children}</main>
      <nav className="no-print fixed inset-x-0 bottom-0 z-20 grid grid-cols-4 border-t bg-card md:hidden">
        {NAV.map((n) => (
          <Link key={n.to} to={n.to} activeOptions={{ exact: true }}
            className="flex flex-col items-center gap-1 py-2 text-[11px] font-semibold text-muted-foreground"
            activeProps={{ className: "text-primary" }}>
            <n.icon className="h-5 w-5" />{n.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}

export function Badge({ clase }: { clase: Clase }) {
  return <span className={`inline-flex min-w-8 justify-center rounded-full px-2.5 py-0.5 text-xs font-bold ${claseStyle[clase]}`}>{clase}</span>;
}

export const inputCls = "w-full rounded-lg border bg-card px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring";
export const btnCls = "inline-flex items-center justify-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground shadow-soft hover:opacity-90";
export const btnGhost = "inline-flex items-center justify-center gap-2 rounded-full border bg-card px-4 py-2 text-sm font-semibold hover:bg-muted";
