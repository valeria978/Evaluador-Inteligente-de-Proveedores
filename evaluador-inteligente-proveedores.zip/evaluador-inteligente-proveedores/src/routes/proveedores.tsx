import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { AppShell, inputCls, btnCls, btnGhost } from "@/components/AppShell";
import { useStore, INSUMOS, estadoDoc, diasParaVencer, uid, type Documento, claseStyle } from "@/lib/evaluador";

export const Route = createFileRoute("/proveedores")({
  head: () => ({
    meta: [
      { title: "Proveedores y documentos | Evaluador Inteligente" },
      { name: "description", content: "Registra proveedores, insumos y documentos sanitarios con alertas de vencimiento." },
      { property: "og:title", content: "Proveedores y documentos | Evaluador Inteligente" },
      { property: "og:description", content: "Registra proveedores, insumos y documentos sanitarios con alertas de vencimiento." },
    ],
  }),
  component: Proveedores,
});

const TIPOS: Documento["tipo"][] = ["Registro sanitario", "Ficha técnica", "Certificado BPM"];

function Proveedores() {
  const { proveedores, update } = useStore();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ nombre: "", insumo: "Harina", contacto: "", docs: { "Registro sanitario": "", "Ficha técnica": "", "Certificado BPM": "" } as Record<string, string> });

  const guardar = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nombre.trim()) return;
    const documentos = TIPOS.filter((t) => form.docs[t]).map((t) => ({ tipo: t, vence: form.docs[t] }));
    update((d) => ({ ...d, proveedores: [...d.proveedores, { id: uid(), nombre: form.nombre.trim(), insumo: form.insumo, contacto: form.contacto, documentos }] }));
    setForm({ nombre: "", insumo: "Harina", contacto: "", docs: { "Registro sanitario": "", "Ficha técnica": "", "Certificado BPM": "" } });
    setOpen(false);
  };

  return (
    <AppShell>
      <div className="mb-5 flex items-center justify-between gap-3">
        <h2 className="text-2xl font-bold">Proveedores</h2>
        <button className={btnCls} onClick={() => setOpen(!open)}><Plus className="h-4 w-4" />Nuevo</button>
      </div>

      {open && (
        <form onSubmit={guardar} className="card-box mb-5 grid gap-3 md:grid-cols-3">
          <label className="text-sm font-semibold">Nombre<input required className={inputCls} value={form.nombre} onChange={(e) => setForm({ ...form, nombre: e.target.value })} /></label>
          <label className="text-sm font-semibold">Insumo<select className={inputCls} value={form.insumo} onChange={(e) => setForm({ ...form, insumo: e.target.value })}>{INSUMOS.map((i) => <option key={i}>{i}</option>)}</select></label>
          <label className="text-sm font-semibold">Contacto<input className={inputCls} value={form.contacto} onChange={(e) => setForm({ ...form, contacto: e.target.value })} /></label>
          {TIPOS.map((t) => (
            <label key={t} className="text-sm font-semibold">{t} — vence<input type="date" className={inputCls} value={form.docs[t]} onChange={(e) => setForm({ ...form, docs: { ...form.docs, [t]: e.target.value } })} /></label>
          ))}
          <div className="flex gap-2 md:col-span-3"><button className={btnCls}>Guardar proveedor</button><button type="button" className={btnGhost} onClick={() => setOpen(false)}>Cancelar</button></div>
        </form>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        {proveedores.map((p) => (
          <article key={p.id} className="card-box">
            <div className="mb-3 flex items-start justify-between gap-2">
              <div>
                <h3 className="text-lg font-semibold">{p.nombre}</h3>
                <p className="text-sm text-muted-foreground"><span className="rounded-full bg-accent px-2 py-0.5 text-xs font-bold text-accent-foreground">{p.insumo}</span> {p.contacto}</p>
              </div>
              <button aria-label="Eliminar" className="text-muted-foreground hover:text-destructive" onClick={() => confirm(`¿Eliminar ${p.nombre}?`) && update((d) => ({ proveedores: d.proveedores.filter((x) => x.id !== p.id), evaluaciones: d.evaluaciones.filter((e) => e.proveedorId !== p.id) }))}><Trash2 className="h-4 w-4" /></button>
            </div>
            <ul className="space-y-1.5 text-sm">
              {TIPOS.map((t) => {
                const doc = p.documentos.find((d) => d.tipo === t);
                if (!doc) return <li key={t} className="flex justify-between"><span>{t}</span><span className={`rounded-full px-2 text-xs font-bold ${claseStyle.Rechazado}`}>Falta</span></li>;
                const st = estadoDoc(doc.vence); const dias = diasParaVencer(doc.vence);
                return (
                  <li key={t} className="flex items-center justify-between gap-2">
                    <span>{t}</span>
                    <span className={`rounded-full px-2 text-xs font-bold ${st === "vencido" ? claseStyle.Rechazado : st === "proximo" ? claseStyle.C : claseStyle.A}`}>
                      {st === "vencido" ? "Vencido" : st === "proximo" ? `Vence en ${dias} d` : `Vigente · ${doc.vence}`}
                    </span>
                  </li>
                );
              })}
            </ul>
          </article>
        ))}
      </div>
    </AppShell>
  );
}
