import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Download, Printer } from "lucide-react";
import { AppShell, Badge, inputCls, btnCls, btnGhost } from "@/components/AppShell";
import { useStore, resultado, sugerencia, CRITERIOS, INSUMOS } from "@/lib/evaluador";

export const Route = createFileRoute("/reporte")({
  head: () => ({
    meta: [
      { title: "Reporte de evaluaciones | Evaluador Inteligente" },
      { name: "description", content: "Historial exportable de lotes evaluados y acciones correctivas." },
      { property: "og:title", content: "Reporte de evaluaciones | Evaluador Inteligente" },
      { property: "og:description", content: "Historial exportable de lotes evaluados y acciones correctivas." },
    ],
  }),
  component: Reporte,
});

function Reporte() {
  const { proveedores, evaluaciones } = useStore();
  const [insumo, setInsumo] = useState("Todos");
  const prov = (id: string) => proveedores.find((p) => p.id === id);
  const filas = evaluaciones
    .filter((e) => prov(e.proveedorId) && (insumo === "Todos" || prov(e.proveedorId)!.insumo === insumo))
    .sort((a, b) => b.fecha.localeCompare(a.fecha))
    .map((e) => ({ e, p: prov(e.proveedorId)!, r: resultado(e) }));

  const csv = () => {
    const head = ["Fecha", "Lote", "Proveedor", "Insumo", ...CRITERIOS.map((c) => c.label), "Puntaje", "Clase", "Acción sugerida", "Observaciones"];
    const rows = filas.map(({ e, p, r }) => [e.fecha, e.lote, p.nombre, p.insumo, ...CRITERIOS.map((c) => e.notas[c.key]), r.puntaje, r.clase, sugerencia(e), e.observaciones]);
    const text = "\uFEFF" + [head, ...rows].map((row) => row.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(";")).join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([text], { type: "text/csv;charset=utf-8" }));
    a.download = `reporte-proveedores-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  };

  return (
    <AppShell>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-2xl font-bold">Reporte de evaluaciones</h2>
        <div className="no-print flex flex-wrap gap-2">
          <select className={`${inputCls} w-auto`} value={insumo} onChange={(e) => setInsumo(e.target.value)}><option>Todos</option>{INSUMOS.map((i) => <option key={i}>{i}</option>)}</select>
          <button className={btnCls} onClick={csv}><Download className="h-4 w-4" />Excel (CSV)</button>
          <button className={btnGhost} onClick={() => window.print()}><Printer className="h-4 w-4" />PDF</button>
        </div>
      </div>
      <div className="space-y-3">
        {filas.map(({ e, p, r }) => (
          <article key={e.id} className="card-box">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-semibold">{p.nombre} <span className="text-xs text-muted-foreground">· {p.insumo}</span></p>
                <p className="text-xs text-muted-foreground">{e.fecha} · Lote {e.lote}</p>
              </div>
              <div className="flex items-center gap-2"><b className="text-xl">{r.puntaje}</b><Badge clase={r.clase} /></div>
            </div>
            <div className="mt-2 grid grid-cols-5 gap-1 text-center text-[11px]">
              {CRITERIOS.map((c) => <div key={c.key} className="rounded bg-muted p-1"><div className="truncate text-muted-foreground">{c.label.split(" ")[0]}</div><b>{e.notas[c.key]}</b></div>)}
            </div>
            <p className="mt-2 text-sm"><b>Acción:</b> {sugerencia(e)}</p>
            {e.observaciones && <p className="text-xs text-muted-foreground">Obs.: {e.observaciones}</p>}
          </article>
        ))}
      </div>
    </AppShell>
  );
}
