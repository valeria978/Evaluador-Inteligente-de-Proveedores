import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend, ReferenceLine } from "recharts";
import { AlertTriangle, Lightbulb } from "lucide-react";
import { AppShell, Badge, inputCls } from "@/components/AppShell";
import { useStore, resultado, clasificar, INSUMOS, estadoDoc, diasParaVencer, sugerencia, claseStyle } from "@/lib/evaluador";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Panel de proveedores | Evaluador Inteligente" },
      { name: "description", content: "Ranking, tendencia y alertas de proveedores de tu panadería." },
      { property: "og:title", content: "Panel de proveedores | Evaluador Inteligente" },
      { property: "og:description", content: "Ranking, tendencia y alertas de proveedores de tu panadería." },
    ],
  }),
  component: Dashboard,
});

const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];

function Dashboard() {
  const { proveedores, evaluaciones } = useStore();
  const [insumo, setInsumo] = useState("Todos");
  const provs = proveedores.filter((p) => insumo === "Todos" || p.insumo === insumo);

  const ranking = useMemo(() => provs.map((p) => {
    const evs = evaluaciones.filter((e) => e.proveedorId === p.id).sort((a, b) => a.fecha.localeCompare(b.fecha));
    const res = evs.map(resultado);
    const prom = res.length ? Math.round((res.reduce((s, r) => s + r.puntaje, 0) / res.length) * 10) / 10 : 0;
    const ultima = evs[evs.length - 1];
    return { p, prom, n: evs.length, rechazos: res.filter((r) => r.rechazado).length, clase: clasificar(prom), ultima };
  }).sort((a, b) => b.prom - a.prom), [provs, evaluaciones]);

  const trend = useMemo(() => {
    const ids = new Set(provs.map((p) => p.id));
    const evs = evaluaciones.filter((e) => ids.has(e.proveedorId)).sort((a, b) => a.fecha.localeCompare(b.fecha));
    const rows: Record<string, Record<string, number | string>> = {};
    evs.forEach((e) => {
      const name = proveedores.find((p) => p.id === e.proveedorId)!.nombre;
      (rows[e.fecha] ??= { fecha: e.fecha.slice(5) })[name] = resultado(e).puntaje;
    });
    return Object.values(rows);
  }, [provs, evaluaciones, proveedores]);

  const alertas = provs.flatMap((p) => p.documentos.filter((d) => estadoDoc(d.vence) !== "vigente").map((d) => ({ p, d })));
  const resumen = { total: ranking.length, ...Object.fromEntries(["A", "B", "C", "D"].map((c) => [c, ranking.filter((r) => r.n && r.clase === c).length])) } as Record<string, number>;

  return (
    <AppShell>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold">Panel general</h2>
          <p className="text-sm text-muted-foreground">Desempeño de tus proveedores de insumos</p>
        </div>
        <select className={`${inputCls} w-auto`} value={insumo} onChange={(e) => setInsumo(e.target.value)} aria-label="Filtrar por insumo">
          <option>Todos</option>{INSUMOS.map((i) => <option key={i}>{i}</option>)}
        </select>
      </div>

      <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-5">
        <div className="card-box"><p className="text-xs text-muted-foreground">Proveedores</p><p className="text-3xl font-bold">{resumen.total}</p></div>
        {(["A", "B", "C", "D"] as const).map((c) => (
          <div key={c} className="card-box flex items-center gap-3">
            <span className={`h-10 w-10 rounded-full ${claseStyle[c]} flex items-center justify-center font-bold`}>{c}</span>
            <p className="text-3xl font-bold">{resumen[c]}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-5">
        <section className="card-box lg:col-span-2">
          <h3 className="mb-3 text-lg font-semibold">Ranking</h3>
          <ol className="space-y-2">
            {ranking.map((r, i) => (
              <li key={r.p.id} className="flex items-center gap-3 rounded-lg bg-muted/60 p-3">
                <span className="w-5 text-center font-display text-lg font-bold text-primary">{i + 1}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{r.p.nombre}</p>
                  <p className="text-xs text-muted-foreground">{r.p.insumo} · {r.n} lotes{r.rechazos ? ` · ${r.rechazos} rechazado(s)` : ""}</p>
                </div>
                <span className="font-bold">{r.n ? r.prom : "—"}</span>
                {r.n > 0 && <Badge clase={r.clase} />}
              </li>
            ))}
            {!ranking.length && <p className="text-sm text-muted-foreground">Sin proveedores para este insumo.</p>}
          </ol>
        </section>

        <section className="card-box lg:col-span-3">
          <h3 className="mb-3 text-lg font-semibold">Tendencia de puntaje</h3>
          <div className="h-72">
            <ResponsiveContainer>
              <LineChart data={trend} margin={{ left: -20, right: 8 }}>
                <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
                <XAxis dataKey="fecha" fontSize={11} />
                <YAxis domain={[0, 100]} fontSize={11} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <ReferenceLine y={90} stroke="var(--grade-a)" strokeDasharray="4 4" />
                <ReferenceLine y={60} stroke="var(--grade-d)" strokeDasharray="4 4" />
                {provs.map((p, i) => <Line key={p.id} type="monotone" dataKey={p.nombre} stroke={COLORS[i % 5]} strokeWidth={2.5} connectNulls dot={{ r: 3 }} />)}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="card-box lg:col-span-2">
          <h3 className="mb-3 flex items-center gap-2 text-lg font-semibold"><AlertTriangle className="h-5 w-5 text-destructive" />Documentos por vencer</h3>
          <ul className="space-y-2 text-sm">
            {alertas.map(({ p, d }) => {
              const dias = diasParaVencer(d.vence);
              return (
                <li key={p.id + d.tipo} className="flex justify-between gap-2 rounded-lg bg-muted/60 p-2.5">
                  <span><b>{p.nombre}</b> · {d.tipo}</span>
                  <span className={`shrink-0 rounded-full px-2 text-xs font-bold ${dias < 0 ? claseStyle.Rechazado : claseStyle.C}`}>{dias < 0 ? `Vencido hace ${-dias} d` : `Vence en ${dias} d`}</span>
                </li>
              );
            })}
            {!alertas.length && <p className="text-muted-foreground">Todo al día ✔</p>}
          </ul>
        </section>

        <section className="card-box lg:col-span-3">
          <h3 className="mb-3 flex items-center gap-2 text-lg font-semibold"><Lightbulb className="h-5 w-5 text-primary" />Acciones correctivas sugeridas</h3>
          <ul className="space-y-2 text-sm">
            {ranking.filter((r) => r.ultima).map((r) => (
              <li key={r.p.id} className="rounded-lg bg-secondary p-3">
                <p className="font-semibold">{r.p.nombre} <span className="text-xs font-normal text-muted-foreground">lote {r.ultima!.lote}</span></p>
                <p className="text-secondary-foreground">{sugerencia(r.ultima!)}</p>
              </li>
            ))}
          </ul>
          <Link to="/evaluar" className="mt-3 inline-block text-sm font-bold text-primary">+ Evaluar un nuevo lote</Link>
        </section>
      </div>
    </AppShell>
  );
}
