import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ShieldAlert } from "lucide-react";
import { AppShell, Badge, inputCls, btnCls } from "@/components/AppShell";
import { useStore, CRITERIOS, INOCUIDAD, calcularPuntaje, clasificar, sugerencia, uid, claseStyle, type CriterioKey, type Evaluacion } from "@/lib/evaluador";

export const Route = createFileRoute("/evaluar")({
  head: () => ({
    meta: [
      { title: "Evaluar lote recibido | Evaluador Inteligente" },
      { name: "description", content: "Califica cada lote por calidad, documentación, transporte, puntualidad y servicio." },
      { property: "og:title", content: "Evaluar lote recibido | Evaluador Inteligente" },
      { property: "og:description", content: "Califica cada lote por calidad, documentación, transporte, puntualidad y servicio." },
    ],
  }),
  component: Evaluar,
});

function Evaluar() {
  const { proveedores, update } = useStore();
  const nav = useNavigate();
  const [provId, setProvId] = useState("");
  const [lote, setLote] = useState("");
  const [fecha, setFecha] = useState(() => new Date().toISOString().slice(0, 10));
  const [notas, setNotas] = useState<Record<CriterioKey, number>>({ calidad: 80, documentacion: 80, transporte: 80, puntualidad: 80, servicio: 80 });
  const [ino, setIno] = useState<Record<string, boolean>>(Object.fromEntries(INOCUIDAD.map((k) => [k, true])));
  const [obs, setObs] = useState("");

  const puntaje = calcularPuntaje(notas);
  const okIno = INOCUIDAD.every((k) => ino[k]);
  const clase = clasificar(puntaje, okIno);
  const borrador: Evaluacion = { id: "", proveedorId: provId, fecha, lote, notas, inocuidad: ino, observaciones: obs };
  const pid = provId || proveedores[0]?.id || "";

  const guardar = (e: React.FormEvent) => {
    e.preventDefault();
    update((d) => ({ ...d, evaluaciones: [...d.evaluaciones, { ...borrador, proveedorId: pid, id: uid(), lote: lote || "L-" + Date.now().toString().slice(-5) }] }));
    nav({ to: "/" });
  };

  return (
    <AppShell>
      <h2 className="mb-5 text-2xl font-bold">Evaluar lote recibido</h2>
      <form onSubmit={guardar} className="grid gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <section className="card-box grid gap-3 md:grid-cols-3">
            <label className="text-sm font-semibold">Proveedor
              <select className={inputCls} value={pid} onChange={(e) => setProvId(e.target.value)}>
                {proveedores.map((p) => <option key={p.id} value={p.id}>{p.nombre} ({p.insumo})</option>)}
              </select>
            </label>
            <label className="text-sm font-semibold">N.º de lote<input className={inputCls} value={lote} onChange={(e) => setLote(e.target.value)} placeholder="L-1234" /></label>
            <label className="text-sm font-semibold">Fecha<input type="date" className={inputCls} value={fecha} onChange={(e) => setFecha(e.target.value)} /></label>
          </section>

          <section className="card-box border-destructive/40">
            <h3 className="mb-2 flex items-center gap-2 font-semibold"><ShieldAlert className="h-5 w-5 text-destructive" />Criterios de inocuidad (obligatorios)</h3>
            <div className="space-y-2">
              {INOCUIDAD.map((k) => (
                <label key={k} className="flex items-center justify-between gap-3 rounded-lg bg-muted/60 p-2.5 text-sm">
                  <span>{k}</span>
                  <span className="flex shrink-0 overflow-hidden rounded-full border text-xs font-bold">
                    <button type="button" onClick={() => setIno({ ...ino, [k]: true })} className={`px-3 py-1 ${ino[k] ? "bg-grade-a text-grade-fg" : ""}`}>Cumple</button>
                    <button type="button" onClick={() => setIno({ ...ino, [k]: false })} className={`px-3 py-1 ${!ino[k] ? "bg-destructive text-grade-fg" : ""}`}>Falla</button>
                  </span>
                </label>
              ))}
            </div>
          </section>

          <section className="card-box space-y-4">
            <h3 className="font-semibold">Calificación por criterio (0–100)</h3>
            {CRITERIOS.map((c) => (
              <div key={c.key}>
                <div className="mb-1 flex justify-between text-sm"><span className="font-semibold">{c.label} <span className="text-muted-foreground">· {c.peso * 100}%</span></span><b>{notas[c.key]}</b></div>
                <input type="range" min={0} max={100} step={5} value={notas[c.key]} onChange={(e) => setNotas({ ...notas, [c.key]: +e.target.value })} className="w-full accent-primary" aria-label={c.label} />
              </div>
            ))}
            <label className="block text-sm font-semibold">Observaciones<textarea className={inputCls} rows={2} value={obs} onChange={(e) => setObs(e.target.value)} /></label>
          </section>
        </div>

        <aside className="card-box h-fit space-y-3 lg:sticky lg:top-4">
          <p className="text-sm text-muted-foreground">Resultado</p>
          <div className="flex items-center gap-3">
            <span className="font-display text-5xl font-bold">{okIno ? puntaje : 0}</span>
            <span className="scale-125"><Badge clase={clase} /></span>
          </div>
          <div className="flex gap-1.5">
            {(["A", "B", "C", "D"] as const).map((c) => <span key={c} className={`h-3 flex-1 rounded-full ${clase === c ? claseStyle[c] : "bg-muted"}`} />)}
          </div>
          {!okIno && <p className="rounded-lg bg-destructive p-3 text-sm font-bold text-destructive-foreground">Lote RECHAZADO automáticamente por falla de inocuidad.</p>}
          <p className="rounded-lg bg-secondary p-3 text-sm"><b>Sugerencia:</b> {sugerencia(borrador)}</p>
          <button className={`${btnCls} w-full`} disabled={!pid}>Guardar evaluación</button>
        </aside>
      </form>
    </AppShell>
  );
}
